package Test;
import java.util.*;
public class LargestNumber {
	public static void main(String args[]) {
		double l=10 , n;
		System.out.println("enter the values os l and n");
		Scanner input=new Scanner(System.in);
		n=input.nextInt();
		
		while(n>l) {
			System.out.println(l);
		}
	}
}
