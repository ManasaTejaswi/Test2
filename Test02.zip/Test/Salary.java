package Test;
import java.util.*;
public class Salary {
	public static void main(String args[]) {
	long hra, pf, s;
Scanner salary=new Scanner(System.in);
System.out.println("enter the salary");
long basic=salary.nextLong();
hra=(50/100)*basic;
System.out.println("hra is " +hra);

pf=(12/100)*basic;
System.out.println("pf is " +pf);

s=(75/100)*basic;
System.out.println("special allowamce is " +s);

}
}
