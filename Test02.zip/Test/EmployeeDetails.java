package Test;
import java.io.IOException;
import java.util.*;
public class EmployeeDetails  {
	public static void main(String args[]) throws message{
		int age=10 ;
		EmployeeDetails obj=new EmployeeDetails();
		List object=new ArrayList();
		Scanner input=new Scanner(System.in);
		System.out.println("enter name");
		object.add(input.next());
		System.out.println("enter age");
		object.add(input.next());
		System.out.println("enter address");
		object.add(input.next());
		
		Iterator iterate=object.iterator();
		while(iterate.hasNext()) {
			System.out.println(iterate.next());
		}
		if(age>20 && age<55) {
			System.out.println(age);
		}
		else {
			throw new message("cannot proceed");
		}
	
	}
}
		class message extends Exception {
			message(String msg){
				super(msg);
			}
		}
	



